import 'dart:ffi';

import 'package:flutter/material.dart';

class CustomTextField extends StatelessWidget {
  final String textFieldText;
  final bool passwordTxt;


  const CustomTextField({required this.textFieldText, required this.passwordTxt, });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      child: TextField(
        obscureText: passwordTxt,
        keyboardType: TextInputType.emailAddress,
        cursorColor: Color(0xffeb5f30),
        decoration: InputDecoration(

            enabledBorder: OutlineInputBorder(
              borderSide: const BorderSide(
                  color: Color(0xffeb5f30), width: 2.0),
              borderRadius: BorderRadius.circular(10.0),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(
                  color: Color(0xffeb5f30), width: 2.0),
              borderRadius: BorderRadius.circular(10.0),
            ),
            labelText: textFieldText,
            labelStyle: TextStyle(
              color: Color(0xffeb5f30),
            )
          // hintText: 'Enter Your Name',
        ),
      ),
    );
  }
}
