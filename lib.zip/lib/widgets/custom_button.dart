import 'package:flutter/material.dart';

class CustomButton extends StatefulWidget {
  late Color color;
  late String nameText;

  CustomButton({required this.color, required this.nameText});

  @override
  State<CustomButton> createState() => _CustomButtonState();
}

class _CustomButtonState extends State<CustomButton> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Container(
        decoration: BoxDecoration(

          borderRadius: BorderRadius.all(Radius.circular(20))
        ),


      ),
    );
  }
}
