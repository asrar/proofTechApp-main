class ProjectModel{
  late String titleText;
  late String sbTitleText;
  ProjectModel({required this.titleText, required this.sbTitleText});
}
List<ProjectModel> dummyProjectList = [
  ProjectModel(
    titleText: 'Project A',
    sbTitleText: 'This is a project A'
  ),
  ProjectModel(
      titleText: 'Project B',
      sbTitleText: 'This is a project B'
  ),
  ProjectModel(
      titleText: 'Project C',
      sbTitleText: 'This is a project C'
  ),
  ProjectModel(
      titleText: 'Project D',
      sbTitleText: 'This is a project D'
  ),
  ProjectModel(
      titleText: 'Project E',
      sbTitleText: 'This is a project E'
  ),
  
];